CREATE OR REPLACE PROCEDURE SP_CONSULTAR_SIN_ADOPTAR(
    meses IN NUMBER,
    tipoMascota IN NUMBER,
    raza IN NUMBER,
    color IN NUMBER,
    p_cursor OUT SYS_REFCURSOR,
    p_total OUT NUMBER
) AS

BEGIN
    SELECT COUNT(DISTINCT p.id) INTO p_total
    FROM Pet p
    LEFT JOIN Breed b ON b.id     = p.idBreed
    LEFT JOIN PetType pt ON pt.id    = b.idPetType
    LEFT JOIN Colour c ON c.id     = p.idColour
    WHERE (pt.id = NVL(tipoMascota, pt.id))
      AND (b.id = NVL(raza, b.id))
      AND (c.id = NVL(color, c.id))
      AND (p.idState = 3) ---Estado En adopción
      AND (ADD_MONTHS(p.foundDate, meses) <= SYSDATE);
      
OPEN p_cursor
    FOR SELECT 
    p.id,
    p.name,
    pt.name,
    b.name,
    c.name,
    TRUNC(MONTHS_BETWEEN(SYSDATE, p.foundDate)),
    p.beforePicture,
    p.afterPicture
    FROM Pet p
    LEFT JOIN Breed b ON b.id = p.idBreed
    LEFT JOIN PetType pt ON pt.id = b.idPetType
    LEFT JOIN Colour c ON c.id     = p.idColour
    WHERE (pt.id = NVL(tipoMascota, pt.id))
      AND (b.id = NVL(raza, b.id))
      AND (c.id = NVL(color, c.id))
      AND (p.idState = 3) ---Estado En adopción
      AND (ADD_MONTHS(p.foundDate, meses) <= SYSDATE)
      ORDER BY p.id DESC;
END SP_CONSULTAR_SIN_ADOPTAR;