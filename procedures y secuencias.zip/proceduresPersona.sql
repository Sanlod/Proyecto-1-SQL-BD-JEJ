-- SP_LISTAR_PERSONASLISTANEGRA
CREATE OR REPLACE PROCEDURE SP_LISTAR_PERSONASLISTANEGRA (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            p.id,
            p.firstName || ' ' ||
            NVL(p.secondName || ' ', '') ||
            p.firstSurname || ' ' ||
            NVL(p.secondSurname, '')  AS full_name,
            p.notes                   AS notes,
            p.idBlacklist
        FROM Person p
        WHERE p.idBlacklist IS NOT NULL
        ORDER BY p.firstSurname, p.firstName;
END SP_LISTAR_PERSONASLISTANEGRA;
/

-- SP_REPORTAR_LISTANEGRA
CREATE OR REPLACE PROCEDURE SP_REPORTAR_LISTANEGRA (
    p_idPerson IN VARCHAR2,
    p_createdBy IN VARCHAR2
) AS
    v_idBlacklist NUMBER;
BEGIN
    INSERT INTO BlackList (
        id, createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_BLACKLIST.NEXTVAL,
        p_createdBy,
        CURRENT_TIMESTAMP,
        p_createdBy,
        CURRENT_TIMESTAMP
    ) RETURNING id INTO v_idBlacklist;

    UPDATE person
    SET idBlacklist = v_idBlacklist,
        modifiedBy  = p_createdBy,
        modifiedAt  = CURRENT_TIMESTAMP
    WHERE id = TO_NUMBER(p_idPerson);

    COMMIT;
END SP_REPORTAR_LISTANEGRA;
/

-- SP_REGISTRAR_CALIFICACION
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_CALIFICACION (
    p_idPerson   IN VARCHAR2,
    p_rating IN VARCHAR2,
    p_notes       IN VARCHAR2,
    p_modifiedBy  IN VARCHAR2
) AS
BEGIN
    UPDATE person
    SET notes      = p_notes,
        modifiedBy = p_modifiedBy,
        modifiedAt = CURRENT_TIMESTAMP
    WHERE id = TO_NUMBER(p_idPerson);
    COMMIT;
END SP_REGISTRAR_CALIFICACION;
/
-- SP_REGISTRAR_PERSONA
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_PERSONA (
    p_firstName     IN VARCHAR2,
    p_secondName    IN VARCHAR2,
    p_firstSurname  IN VARCHAR2,
    p_secondSurname IN VARCHAR2
) AS
BEGIN
    INSERT INTO Person (
        id, firstName, secondName, firstSurname, secondSurname,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_PERSON.NEXTVAL,
        p_firstName,
        p_secondName,
        p_firstSurname,
        p_secondSurname,
        USER,
        CURRENT_TIMESTAMP,
        USER,
        CURRENT_TIMESTAMP
    );
    COMMIT;
END;
/
-- LISTAR_NOTASPERSONA
CREATE OR REPLACE PROCEDURE SP_LISTAR_NOTASPERSONA (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, notes FROM Person
        WHERE notes IS NOT NULL
        ORDER BY id;
END SP_LISTAR_NOTASPERSONA;
/
-- LISTAR_PERSONAS CON DATOS EXTRA (CRUD)
CREATE OR REPLACE PROCEDURE SP_LISTAR_PERSONAS_CRUD (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT 
            p.id,
            p.firstName || ' ' || 
            NVL(p.secondName || ' ', '') || 
            p.firstSurname || ' ' || 
            NVL(p.secondSurname, '') AS nombre_completo,
            CASE WHEN p.idBlacklist IS NOT NULL THEN 'Sí' ELSE 'No' END AS en_lista_negra,
            NVL(p.notes, '') AS notas
        FROM Person p
        ORDER BY p.firstSurname, p.firstName;
END;
/

--SP_ELIMINAR_PERSONA
CREATE OR REPLACE PROCEDURE SP_ELIMINAR_PERSONA (
    p_id IN NUMBER
) AS
BEGIN
    DELETE FROM Person WHERE id = p_id;
    COMMIT;
END SP_ELIMINAR_PERSONA;
/
--SP_OBTENER_CALIFICACION_PERSONA
CREATE OR REPLACE PROCEDURE SP_OBTENER_CALIFICACION_PERSONA (
    p_idPerson IN NUMBER,
    p_cursor   OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT rating 
        FROM Person 
        WHERE id = p_idPerson;
END SP_OBTENER_CALIFICACION_PERSONA;
/