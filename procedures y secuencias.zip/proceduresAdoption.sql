-- SP_LISTAR_MASCOTAS
CREATE OR REPLACE PROCEDURE SP_LISTAR_MASCOTAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name FROM pet ORDER BY name;
END SP_LISTAR_MASCOTAS;
/

-- SP_LISTAR_ADOPTANTES
CREATE OR REPLACE PROCEDURE SP_LISTAR_ADOPTANTES (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            p.id,
            p.firstName || ' ' ||
            NVL(p.secondName || ' ', '') ||
            p.firstSurname || ' ' ||
            NVL(p.secondSurname, '') AS full_name
        FROM person p
        ORDER BY p.firstSurname;
END SP_LISTAR_ADOPTANTES;
/

-- SP_CONSULTAR_SOLICITUDES
CREATE OR REPLACE PROCEDURE SP_CONSULTAR_SOLICITUDES (
    p_from       IN  DATE,
    p_until      IN  DATE,
    p_idPet      IN  VARCHAR2,
    p_idAdoptant IN  VARCHAR2,
    p_cursor     OUT SYS_REFCURSOR,
    p_total      OUT NUMBER
) AS
BEGIN
    SELECT COUNT(*) INTO p_total
    FROM AdoptionRequest ar
    JOIN Adoption a  ON a.id  = ar.idAdoption
    JOIN Pet p       ON p.id  = a.idPet
    JOIN Person pe   ON pe.id = a.idPerson
    JOIN Status s    ON s.id  = ar.idStatus
    WHERE (p_from       IS NULL OR ar.createdAt >= p_from)
      AND (p_until      IS NULL OR ar.createdAt <= p_until)
      AND (p_idPet      IS NULL OR a.idPet    = TO_NUMBER(p_idPet))
      AND (p_idAdoptant IS NULL OR a.idPerson = TO_NUMBER(p_idAdoptant));

    OPEN p_cursor FOR
        SELECT
            ar.id,
            p.name                                    AS pet,
            pe.firstName || ' ' || pe.firstSurname   AS adoptant,
            ar.createdAt                              AS request_date,
            s.name                                    AS status
        FROM AdoptionRequest ar
        JOIN Adoption a  ON a.id  = ar.idAdoption
        JOIN Pet p       ON p.id  = a.idPet
        JOIN Person pe   ON pe.id = a.idPerson
        JOIN Status s    ON s.id  = ar.idStatus
        WHERE (p_from       IS NULL OR ar.createdAt >= p_from)
          AND (p_until      IS NULL OR ar.createdAt <= p_until)
          AND (p_idPet      IS NULL OR a.idPet    = TO_NUMBER(p_idPet))
          AND (p_idAdoptant IS NULL OR a.idPerson = TO_NUMBER(p_idAdoptant))
        ORDER BY ar.createdAt DESC;
END SP_CONSULTAR_SOLICITUDES;
/

-- SP_REGISTRAR_ADOPCION
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_ADOPCION (
    p_idPet        IN  VARCHAR2,
    p_idPerson     IN  VARCHAR2,
    p_notes        IN  VARCHAR2,
    p_photo        IN  BLOB,      
    p_photoNew     IN  BLOB,      
    p_createdBy    IN  VARCHAR2,
    p_result       OUT NUMBER,
    p_idRequest    OUT NUMBER
) AS
    v_idAdoption NUMBER;
    v_idStatus   NUMBER;
    v_idState    NUMBER;
    v_idRequest  NUMBER;
BEGIN
    INSERT INTO Adoption (
        id, idPet, idPerson, notes, photo, photoNew, adoptionDate,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_ADOPTION.NEXTVAL,
        TO_NUMBER(p_idPet),
        TO_NUMBER(p_idPerson),
        p_notes,
        p_photo,
        p_photoNew,
        CURRENT_TIMESTAMP,
        p_createdBy, CURRENT_TIMESTAMP,
        p_createdBy, CURRENT_TIMESTAMP
    ) RETURNING id INTO v_idAdoption;

    SELECT id INTO v_idStatus FROM Status
    WHERE UPPER(name) = 'PENDING' AND ROWNUM = 1;

    INSERT INTO AdoptionRequest (
        id, idStatus, idAdoption,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_ADOPTIONREQUEST.NEXTVAL,
        v_idStatus,
        v_idAdoption,
        p_createdBy, CURRENT_TIMESTAMP,
        p_createdBy, CURRENT_TIMESTAMP
    ) RETURNING id INTO v_idRequest;

    p_idRequest := v_idRequest;

    SELECT id INTO v_idState FROM State
    WHERE UPPER(name) = 'ADOPTED' AND ROWNUM = 1;

    UPDATE Pet SET idState = v_idState WHERE id = TO_NUMBER(p_idPet);

    p_result := 0;
    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN ROLLBACK; p_result := 1; p_idRequest := -1;
    WHEN OTHERS THEN ROLLBACK; p_result := 1; p_idRequest := -1;
END SP_REGISTRAR_ADOPCION;
/
--SP_GESTIONAR_SOLICITUD
CREATE OR REPLACE PROCEDURE SP_GESTIONAR_SOLICITUD (
    p_idSolicitud IN  VARCHAR2,
    p_nuevoEstado IN  VARCHAR2,
    p_usuario     IN  VARCHAR2,
    p_resultado   OUT NUMBER
) AS
BEGIN
    UPDATE AdoptionRequest
    SET idStatus   = TO_NUMBER(p_nuevoEstado),
        modifiedBy = p_usuario,
        modifiedAt = CURRENT_TIMESTAMP
    WHERE id = TO_NUMBER(p_idSolicitud);

    IF SQL%ROWCOUNT = 0 THEN
        p_resultado := 1;
    ELSE
        p_resultado := 0;
        COMMIT;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        p_resultado := 1;
END SP_GESTIONAR_SOLICITUD;
/
--SP_LISTAR_PREGUNTAS
CREATE OR REPLACE PROCEDURE SP_LISTAR_PREGUNTAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, text FROM Question ORDER BY id;
END SP_LISTAR_PREGUNTAS;
/
--SP_REGISTRAR_RESPUESTA
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_RESPUESTA (
    p_idPregunta   IN VARCHAR2,
    p_idRequest    IN VARCHAR2,
    p_valor        IN VARCHAR2,
    p_createdBy    IN VARCHAR2
) AS
BEGIN
    INSERT INTO Answer (
        id, idQuestion, idAdoptionRequest, value,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_ANSWER.NEXTVAL,
        TO_NUMBER(p_idPregunta),
        TO_NUMBER(p_idRequest),
        p_valor,
        p_createdBy, CURRENT_TIMESTAMP,
        p_createdBy, CURRENT_TIMESTAMP
    );
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END SP_REGISTRAR_RESPUESTA;
/
--SP_LISTAR_ESTADOS_SOLICITUD
CREATE OR REPLACE PROCEDURE SP_LISTAR_ESTADOS_SOLICITUD (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name FROM Status ORDER BY name;
END SP_LISTAR_ESTADOS_SOLICITUD;
/
--SP_SEGUIMIENTO_MASCOTA
CREATE OR REPLACE PROCEDURE SP_SEGUIMIENTO_MASCOTA (
    p_idPet  IN  VARCHAR2,
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            a.id,
            pe.firstName || ' ' || pe.firstSurname AS adoptant,
            a.notes,
            a.adoptionDate,
            a.photo,
            a.photoNew
        FROM Adoption a
        JOIN Person pe ON pe.id = a.idPerson
        WHERE a.idPet = TO_NUMBER(p_idPet)
        ORDER BY a.adoptionDate DESC;
END SP_SEGUIMIENTO_MASCOTA;
/