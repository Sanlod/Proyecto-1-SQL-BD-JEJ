-- SP_LISTAR_ASOCIACIONES 
CREATE OR REPLACE PROCEDURE SP_LISTAR_ASOCIACIONES (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id,
               name AS association_name
        FROM Association
        ORDER BY name;
END SP_LISTAR_ASOCIACIONES;
/

-- SP_REGISTRAR_ASOCIACION
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_ASOCIACION (
    p_nombre    IN VARCHAR2,
    p_createdBy IN VARCHAR2
) AS
BEGIN
    INSERT INTO Association (
        id, name,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_ASSOCIATION.NEXTVAL,
        p_nombre,
        p_createdBy,
        CURRENT_TIMESTAMP,
        p_createdBy,
        CURRENT_TIMESTAMP
    );
    COMMIT;
END SP_REGISTRAR_ASOCIACION;
/

-- SP_CONSULTAR_ASOCIACIONES
CREATE OR REPLACE PROCEDURE SP_CONSULTAR_ASOCIACIONES (
    p_nombre  IN  VARCHAR2,
    p_cursor  OUT SYS_REFCURSOR,
    p_total   OUT NUMBER
) AS
BEGIN
    SELECT COUNT(*) INTO p_total
    FROM Association
    WHERE (p_nombre IS NULL OR UPPER(name) LIKE UPPER('%' || p_nombre || '%'));

    OPEN p_cursor FOR
        SELECT id, name
        FROM Association
        WHERE (p_nombre IS NULL OR UPPER(name) LIKE UPPER('%' || p_nombre || '%'))
        ORDER BY name;
END SP_CONSULTAR_ASOCIACIONES;
/