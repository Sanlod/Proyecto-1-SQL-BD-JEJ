-- SP_CONSULTAR_RECOMPENSAS
CREATE OR REPLACE PROCEDURE SP_CONSULTAR_RECOMPENSAS (
    p_idPet  IN  VARCHAR2,
    p_cursor OUT SYS_REFCURSOR,
    p_total  OUT NUMBER
) AS
BEGIN
    SELECT COUNT(*) INTO p_total
    FROM Bounty b
    WHERE (p_idPet IS NULL OR b.idPet = TO_NUMBER(p_idPet))
      AND b.claimed = 0;

    OPEN p_cursor FOR
        SELECT
            b.id,
            b.amount   AS monto,
            c.name     AS moneda,
            p.name     AS mascota,
            b.claimed  AS reclamada
        FROM Bounty b
        JOIN Currency c ON c.id = b.idCurrency
        JOIN Pet p      ON p.id = b.idPet
        WHERE (p_idPet IS NULL OR b.idPet = TO_NUMBER(p_idPet))
          AND b.claimed = 0
        ORDER BY b.id DESC;
END SP_CONSULTAR_RECOMPENSAS;
/
-- SP_REGISTRAR_RECOMPENSA
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_RECOMPENSA (
    p_amount     IN VARCHAR2,
    p_idPet      IN VARCHAR2,
    p_idCurrency IN VARCHAR2
) AS
BEGIN
    INSERT INTO Bounty (
        id, amount, idPet, idCurrency, claimed,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_BOUNTY.NEXTVAL,
        TO_NUMBER(p_amount),
        TO_NUMBER(p_idPet),
        TO_NUMBER(p_idCurrency),
        0,
        'SYSTEM', CURRENT_TIMESTAMP,
        'SYSTEM', CURRENT_TIMESTAMP
    );
    COMMIT;
END SP_REGISTRAR_RECOMPENSA;
/
-- SP_DONAR_RECOMPENSA
CREATE OR REPLACE PROCEDURE SP_DONAR_RECOMPENSA (
    p_idBounty      IN VARCHAR2,
    p_idAssociation IN VARCHAR2,
    p_modifiedBy    IN VARCHAR2
) AS
    v_amount     NUMBER;
    v_idPerson   NUMBER;
    v_idDonation NUMBER;
BEGIN
    SELECT b.amount, r.id
    INTO v_amount, v_idPerson
    FROM Bounty b
    JOIN Pet p      ON p.id = b.idPet
    JOIN Rescuer r  ON r.id = p.idRescuer
    WHERE b.id = TO_NUMBER(p_idBounty)
      AND b.claimed = 0;

    SELECT seqDonation.NEXTVAL INTO v_idDonation FROM dual;

    INSERT INTO Donation (
        id, donation_date, amount, percentageXAssociation, idPerson,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        v_idDonation, CURRENT_TIMESTAMP, v_amount, 100, v_idPerson,
        p_modifiedBy, CURRENT_TIMESTAMP, p_modifiedBy, CURRENT_TIMESTAMP
    );

    INSERT INTO AssociationXDonation (idDonation, idAssociation)
    VALUES (v_idDonation, TO_NUMBER(p_idAssociation));

    UPDATE Bounty
    SET claimed    = 1,
        modifiedBy = p_modifiedBy,
        modifiedAt = CURRENT_TIMESTAMP
    WHERE id = TO_NUMBER(p_idBounty);

    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Recompensa no encontrada o ya reclamada.');
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END SP_DONAR_RECOMPENSA;
/