CREATE OR REPLACE PROCEDURE SP_EDITAR_CATALOGO (
    p_tabla      IN VARCHAR2,
    p_id         IN NUMBER,
    p_nuevoValor IN VARCHAR2
) AS
BEGIN
    EXECUTE IMMEDIATE
        'UPDATE ' || p_tabla ||
        ' SET name = :1, modifiedBy = USER, modifiedAt = CURRENT_TIMESTAMP WHERE id = :2'
        USING p_nuevoValor, p_id;
    COMMIT;
END SP_EDITAR_CATALOGO;
/

CREATE OR REPLACE PROCEDURE SP_AGREGAR_CATALOGO (
    p_tabla IN VARCHAR2,
    p_valor IN VARCHAR2
) AS
BEGIN
    EXECUTE IMMEDIATE
        'INSERT INTO ' || p_tabla ||
        ' (id, name, createdBy, createdAt, modifiedBy, modifiedAt)' ||
        ' VALUES (SEQ_' || UPPER(p_tabla) || '.NEXTVAL, :1, USER, CURRENT_TIMESTAMP, USER, CURRENT_TIMESTAMP)'
        USING p_valor;
    COMMIT;
END SP_AGREGAR_CATALOGO;
/

CREATE OR REPLACE PROCEDURE SP_EXISTE_CATALOGO (
    p_tabla  IN  VARCHAR2,
    p_valor  IN  VARCHAR2,
    p_existe OUT NUMBER
) AS
BEGIN
    EXECUTE IMMEDIATE
        'SELECT COUNT(*) FROM ' || p_tabla || ' WHERE UPPER(name) = UPPER(:1)'
        INTO p_existe
        USING p_valor;
END SP_EXISTE_CATALOGO;
/