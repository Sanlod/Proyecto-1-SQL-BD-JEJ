CREATE OR REPLACE PROCEDURE SP_AUTENTICAR_USUARIO (
    p_username IN  VARCHAR2,
    p_password IN  VARCHAR2,
    p_userType OUT NUMBER,
    p_status   OUT NUMBER
) 
AS
BEGIN
    SELECT IDUSERTYPE, 1 
    INTO p_userType, p_status FROM appUser 
    WHERE (USERNAME = p_username OR EMAIL = p_username) AND PASSWORD = p_password;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        p_userType := -1;
        p_status   := 0;
    WHEN OTHERS THEN
        p_userType := -1;
        p_status   := 0;
END;