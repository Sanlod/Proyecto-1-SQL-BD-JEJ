-- Secuencia para los tipos de usuario
CREATE SEQUENCE seq_userType
    START WITH 1
    INCREMENT BY 1
    NOMAXVALUE
    NOCACHE;

-- Secuencia para los usuarios
CREATE SEQUENCE seq_appUser
    START WITH 1
    INCREMENT BY 1
    NOMAXVALUE
    NOCACHE;