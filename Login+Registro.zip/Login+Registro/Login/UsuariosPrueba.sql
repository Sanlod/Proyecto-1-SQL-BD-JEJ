INSERT INTO appUser (USERNAME, EMAIL, PASSWORD, IDUSERTYPE, CREATEDBY) 
VALUES ('admin', 'admin@sistema.com', 'admin123', 1, 'SYSTEM');

INSERT INTO appUser (USERNAME, EMAIL, PASSWORD, IDUSERTYPE, CREATEDBY) 
VALUES ('juan', 'juan@correo.com', 'user123', 2, 'SYSTEM');

COMMIT;