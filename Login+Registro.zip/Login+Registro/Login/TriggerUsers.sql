CREATE OR REPLACE TRIGGER trg_appUser_id
BEFORE INSERT ON appUser
FOR EACH ROW
BEGIN
   IF :NEW.id IS NULL THEN
      :NEW.id := seq_appUser.NEXTVAL;
   END IF;
END;
/