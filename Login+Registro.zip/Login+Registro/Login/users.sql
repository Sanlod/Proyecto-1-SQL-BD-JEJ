CREATE TABLE appUser (
    id NUMBER PRIMARY KEY USING INDEX TABLESPACE PR_INDEX,
    username VARCHAR2(50) NOT NULL UNIQUE,
    email VARCHAR2(100) NOT NULL UNIQUE,
    password VARCHAR2(255) NOT NULL, -- Longitud extendida para hashes
    idUserType NUMBER NOT NULL,
    createdBy VARCHAR2(100) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modifiedBy VARCHAR2(100),
    modifiedAt TIMESTAMP,
    
    CONSTRAINT fk_user_type FOREIGN KEY (idUserType) REFERENCES userType(id)
) TABLESPACE PR_DATA;

ALTER TABLE appUser 
MODIFY idUserType DEFAULT 2;

ALTER TABLE appUser 
MODIFY createdAt DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE appUser 
ADD CONSTRAINT uk_username UNIQUE (username);