CREATE OR REPLACE PROCEDURE sp_make_admin(p_user_id IN NUMBER) IS
BEGIN
    UPDATE appUser 
    SET idUserType = 1, -- 1 es Administrador
        modifiedAt = CURRENT_TIMESTAMP,
        modifiedBy = 'SYSTEM_CHANGE'
    WHERE id = p_user_id;
    
    IF SQL%NOTFOUND THEN
       RAISE_APPLICATION_ERROR(-20002, 'El ID de usuario no existe.');
    END IF;
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Usuario ascendido a Administrador exitosamente.');
END;
/