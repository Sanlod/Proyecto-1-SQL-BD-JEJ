INSERT INTO userType (id, name, createdBy) 
VALUES (seq_userType.NEXTVAL, 'Administrador', 'AlejandroHerrera');

INSERT INTO userType (id, name, createdBy) 
VALUES (seq_userType.NEXTVAL, 'Usuario', 'AlejandroHerrera');

COMMIT;