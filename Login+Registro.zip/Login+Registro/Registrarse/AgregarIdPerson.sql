ALTER TABLE appUser
    ADD idPerson Number NOT NULL;
    
ALTER TABLE appUser
    ADD CONSTRAINT fk_Person FOREIGN KEY (idPerson) REFERENCES Person(id);
    

    
    
