CREATE OR REPLACE PROCEDURE SP_REGISTRAR_USUARIO_COMPLETO (
    p_firstName      IN  VARCHAR2,
    p_secondName     IN  VARCHAR2,
    p_firstSurname   IN  VARCHAR2,
    p_secondSurname  IN  VARCHAR2,
    p_username       IN  VARCHAR2,
    p_email          IN  VARCHAR2,
    p_password       IN  VARCHAR2,
    p_createdBy      IN  VARCHAR2,
    p_result         OUT NUMBER
) AS
    v_newPersonId NUMBER;
BEGIN
    -- 1. Insertar Persona
    INSERT INTO Person (
        id, firstName, secondName, firstSurname, secondSurname,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_PERSON.NEXTVAL,
        p_firstName, p_secondName, p_firstSurname, p_secondSurname,
        p_createdBy, CURRENT_TIMESTAMP, p_createdBy, CURRENT_TIMESTAMP
    ) RETURNING id INTO v_newPersonId;

    -- 2. Insertar el Usuario vinculado
    INSERT INTO AppUser (
        id,             
        username, 
        email, 
        password, 
        idUserType, 
        idPerson,       
        createdBy, 
        createdAt
    ) VALUES (
        v_newPersonId,  
        p_username,
        p_email,
        p_password,
        2,             
        v_newPersonId, 
        p_createdBy, 
        CURRENT_TIMESTAMP
    );

    p_result := 0; -- Bien
    COMMIT;

EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        ROLLBACK;
        p_result := 2; -- Email o Usuario ya existen
    WHEN OTHERS THEN
        ROLLBACK;
        p_result := 1; -- Otro error
END SP_REGISTRAR_USUARIO_COMPLETO;