CREATE OR REPLACE PROCEDURE SP_MARCAR_HALLADA (
    p_idPet      IN  VARCHAR2,
    p_modifiedBy IN  VARCHAR2,
    p_resultado  OUT NUMBER
) AS
BEGIN
    UPDATE Pet 
    SET idState = (SELECT id FROM State WHERE UPPER(name) = 'HALLADA'),
        modifiedBy = p_modifiedBy,
        modifiedAt = CURRENT_TIMESTAMP
    WHERE id = TO_NUMBER(p_idPet);
    
    p_resultado := SQL%ROWCOUNT;
    COMMIT;
END SP_MARCAR_HALLADA;
/

CREATE OR REPLACE PROCEDURE SP_PAGAR_RECOMPENSA(
    p_idRescuer  IN VARCHAR2,
    p_idPet      IN VARCHAR2,
    p_modifiedBy IN VARCHAR2,
    p_resultado  OUT NUMBER
) AS
    v_idBounty NUMBER;
    v_amount   NUMBER;
BEGIN
    SELECT id, amount INTO v_idBounty, v_amount
    FROM Bounty
    WHERE idPet = TO_NUMBER(p_idPet) 
      AND claimed = 0
      AND ROWNUM = 1;

    UPDATE Bounty
    SET claimed       = 1,
        idPersonFound = TO_NUMBER(p_idRescuer),
        modifiedBy    = p_modifiedBy,
        modifiedAt    = CURRENT_TIMESTAMP
    WHERE id = v_idBounty;

    p_resultado := 0;  
    COMMIT;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        p_resultado := 1;
        ROLLBACK;
    WHEN OTHERS THEN
        ROLLBACK;
        p_resultado := 2;  
END SP_PAGAR_RECOMPENSA;
/
CREATE OR REPLACE PROCEDURE SP_LISTAR_RESCATISTAS(
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT 
            p.id,
            p.firstName || ' ' || 
            NVL(p.secondName || ' ', '') || 
            p.firstSurname || ' ' || 
            NVL(p.secondSurname, '') AS full_name
        FROM Person p
        LEFT JOIN Rescuer r ON r.id = p.id
        WHERE r.id IS NOT NULL 
        ORDER BY p.firstSurname, p.firstName;
END SP_LISTAR_RESCATISTAS;
/

