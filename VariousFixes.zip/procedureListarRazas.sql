CREATE OR REPLACE PROCEDURE SP_LISTAR_TODAS_RAZAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name 
        FROM Breed 
        ORDER BY name;
END SP_LISTAR_TODAS_RAZAS;
/