ALTER TABLE Bounty ADD idPersonFound NUMBER;
ALTER TABLE Bounty ADD CONSTRAINT fk_bounty_person_found 
    FOREIGN KEY (idPersonFound) REFERENCES Person(id);