--SP_LISTAR_MASCOTASPERDIDAS
CREATE OR REPLACE PROCEDURE SP_LISTAR_MASCOTASPERDIDAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            p.id,
            p.name
        FROM Pet p
        JOIN State s ON s.id = p.idState
        WHERE UPPER(s.name) = 'LOST'
        ORDER BY p.name;
END SP_LISTAR_MASCOTASPERDIDAS;
/
--SP_LISTAR_MASCOTASHALLADAS
 CREATE OR REPLACE PROCEDURE SP_LISTAR_MASCOTASHALLADAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            p.id,
            p.name
        FROM Pet p
        JOIN State s on s.id = p.idState
        WHERE UPPER(s.name) = 'FOUND'
        ORDER BY p.name;
END SP_LISTAR_MASCOTASHALLADAS;
/
--SP_LISTAR_ESTADOSMATCH
CREATE OR REPLACE PROCEDURE SP_LISTAR_ESTADOSMATCH (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name FROM MatchStatus ORDER BY name;
END SP_LISTAR_ESTADOSMATCH;
/
--SP_CAMBIAR_ESTADOMATCH
CREATE OR REPLACE PROCEDURE SP_CAMBIAR_ESTADOMATCH (
    p_id         IN NUMBER,
    p_idStatus   IN NUMBER,
    p_modifiedBy IN VARCHAR2
) AS
BEGIN
    UPDATE Match
    SET idMatchStatus = p_idstatus,
        modifiedBy = p_modifiedBy,
        modifiedAt = CURRENT_TIMESTAMP
    WHERE id = p_id;
    
    COMMIT;
END SP_CAMBIAR_ESTADOMATCH;
/
--SP_CONSULTAR_MATCHES
CREATE OR REPLACE PROCEDURE SP_CONSULTAR_MATCHES (
    p_idMascotaPerdida IN VARCHAR2,
    p_idTipo           IN VARCHAR2,
    p_idRaza           IN VARCHAR2,
    p_nombre           IN VARCHAR2,
    p_idChip           IN VARCHAR2,  
    p_idColor          IN VARCHAR2,  
    p_idEstado         IN VARCHAR2,
    p_idProvincia      IN VARCHAR2,
    p_idCanton         IN VARCHAR2,
    p_idDistrito       IN VARCHAR2,
    p_idAsociacion     IN VARCHAR2,
    p_cursor           OUT SYS_REFCURSOR,
    p_total            OUT NUMBER
) AS
BEGIN
    SELECT COUNT(*) INTO p_total
    FROM Match m
    JOIN Pet pp         ON pp.id = m.lostPetID
    JOIN Pet ph         ON ph.id = m.foundPetID
    JOIN Breed b        ON b.id  = pp.idBreed
    JOIN PetType pt     ON pt.id = b.idPetType
    JOIN Colour col     ON col.id = pp.idColour
    LEFT JOIN Chip ch ON ch.petID = pp.id
    JOIN MatchStatus ms ON ms.id = m.idMatchStatus 
    LEFT JOIN District d    ON d.id   = pp.idDistrict
    LEFT JOIN Canton can    ON can.id = d.idCanton
    LEFT JOIN Province pr   ON pr.id  = can.idProvince
    LEFT JOIN Association a ON a.id   = pp.idAssociation
    WHERE (p_idMascotaPerdida IS NULL OR m.lostPetID      = TO_NUMBER(p_idMascotaPerdida))
      AND (p_idTipo           IS NULL OR pt.id            = TO_NUMBER(p_idTipo))
      AND (p_idRaza           IS NULL OR b.id             = TO_NUMBER(p_idRaza))
      AND (p_nombre           IS NULL OR UPPER(pp.name)   LIKE '%' || UPPER(p_nombre) || '%')
      AND (p_idChip IS NULL OR TO_CHAR(ch.chipNumber) LIKE '%' || p_idChip || '%')
      AND (p_idColor          IS NULL OR col.id           = TO_NUMBER(p_idColor))
      AND (p_idEstado         IS NULL OR ms.id            = TO_NUMBER(p_idEstado))
      AND (p_idProvincia      IS NULL OR pr.id            = TO_NUMBER(p_idProvincia))
      AND (p_idCanton         IS NULL OR can.id           = TO_NUMBER(p_idCanton))
      AND (p_idDistrito       IS NULL OR d.id             = TO_NUMBER(p_idDistrito))
      AND (p_idAsociacion     IS NULL OR a.id             = TO_NUMBER(p_idAsociacion));

    OPEN p_cursor FOR
        SELECT
            m.id,
            pp.name                AS mascota_perdida,
            ph.name                AS mascota_hallada,
            pt.name                AS tipo,
            b.name                 AS raza,
            col.name               AS color,
            m.similarityPercentage AS similitud,
            ms.name                AS estado_match,
            ch.chipNumber AS chip,
            m.matchDate            AS fecha_match
        FROM Match m
        JOIN Pet pp         ON pp.id = m.lostPetID
        JOIN Pet ph         ON ph.id = m.foundPetID
        JOIN Breed b        ON b.id  = pp.idBreed
        JOIN PetType pt     ON pt.id = b.idPetType
        JOIN Colour col     ON col.id = pp.idColour
        JOIN MatchStatus ms ON ms.id = m.idMatchStatus
        LEFT JOIN Chip ch ON ch.petID = pp.id
        LEFT JOIN District d    ON d.id   = pp.idDistrict
        LEFT JOIN Canton can    ON can.id = d.idCanton
        LEFT JOIN Province pr   ON pr.id  = can.idProvince
        LEFT JOIN Association a ON a.id   = pp.idAssociation
        WHERE (p_idMascotaPerdida IS NULL OR m.lostPetID      = TO_NUMBER(p_idMascotaPerdida))
          AND (p_idTipo           IS NULL OR pt.id            = TO_NUMBER(p_idTipo))
          AND (p_idRaza           IS NULL OR b.id             = TO_NUMBER(p_idRaza))
          AND (p_nombre           IS NULL OR UPPER(pp.name)   LIKE '%' || UPPER(p_nombre) || '%')
          AND (p_idChip IS NULL OR TO_CHAR(ch.chipNumber) LIKE '%' || p_idChip || '%')
          AND (p_idColor          IS NULL OR col.id           = TO_NUMBER(p_idColor))
          AND (p_idEstado         IS NULL OR ms.id            = TO_NUMBER(p_idEstado))
          AND (p_idProvincia      IS NULL OR pr.id            = TO_NUMBER(p_idProvincia))
          AND (p_idCanton         IS NULL OR can.id           = TO_NUMBER(p_idCanton))
          AND (p_idDistrito       IS NULL OR d.id             = TO_NUMBER(p_idDistrito))
          AND (p_idAsociacion     IS NULL OR a.id             = TO_NUMBER(p_idAsociacion))
        ORDER BY m.matchDate DESC;
END SP_CONSULTAR_MATCHES;
/