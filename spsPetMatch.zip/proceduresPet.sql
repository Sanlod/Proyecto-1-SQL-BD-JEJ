-- SP_LISTAR_TIPOS
CREATE OR REPLACE PROCEDURE SP_LISTAR_TIPOS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM PetType
        ORDER BY name;
END SP_LISTAR_TIPOS;
/

-- SP_LISTAR_COLORES
CREATE OR REPLACE PROCEDURE SP_LISTAR_COLORES (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM Colour
        ORDER BY name;
END SP_LISTAR_COLORES;
/

-- SP_LISTAR_ESTADOS
CREATE OR REPLACE PROCEDURE SP_LISTAR_ESTADOS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM State
        ORDER BY name;
END SP_LISTAR_ESTADOS;
/

-- SP_LISTAR_SEVERIDADES
CREATE OR REPLACE PROCEDURE SP_LISTAR_SEVERIDADES (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM Severity
        ORDER BY name;
END SP_LISTAR_SEVERIDADES;
/

-- SP_LISTAR_NIV_ENERGIA
CREATE OR REPLACE PROCEDURE SP_LISTAR_NIV_ENERGIA (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM EnergyLevel
        ORDER BY name;
END SP_LISTAR_NIV_ENERGIA;
/

-- SP_LISTAR_RAZAS
CREATE OR REPLACE PROCEDURE SP_LISTAR_RAZAS (
    p_idType IN VARCHAR2,
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM Breed
        WHERE (p_idType IS NULL OR idPetType = TO_NUMBER(p_idType))
        ORDER BY name;
END SP_LISTAR_RAZAS;
/

-- SP_LISTAR_RESCATISTAS
CREATE OR REPLACE PROCEDURE SP_LISTAR_RESCATISTAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT r.id,
               p.firstName || ' ' || p.firstSurname AS name
        FROM Rescuer r
        JOIN Person p ON p.id = r.id
        ORDER BY p.firstSurname;
END SP_LISTAR_RESCATISTAS;
/

-- SP_LISTAR_VETERINARIOS
CREATE OR REPLACE PROCEDURE SP_LISTAR_VETERINARIOS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT v.id,
               p.firstName || ' ' || p.firstSurname AS name
        FROM Veterinarian v
        JOIN Person p ON p.id = v.id
        ORDER BY p.firstSurname;
END SP_LISTAR_VETERINARIOS;
/

-- SP_LISTAR_CASASCUNA
CREATE OR REPLACE PROCEDURE SP_LISTAR_CASASCUNA (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT ch.id,
               p.firstName || ' ' || p.firstSurname AS name
        FROM CribHouse ch
        JOIN Person p ON p.id = ch.id
        ORDER BY p.firstSurname;
END SP_LISTAR_CASASCUNA;
/

-- SP_LISTAR_ASOCIACIONES
CREATE OR REPLACE PROCEDURE SP_LISTAR_ASOCIACIONES (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM Association
        ORDER BY name;
END SP_LISTAR_ASOCIACIONES;
/

-- SP_LISTAR_MONEDAS
CREATE OR REPLACE PROCEDURE SP_LISTAR_MONEDAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM Currency
        ORDER BY name;
END SP_LISTAR_MONEDAS;
/

-- SP_LISTAR_DIF_ENTRENAMIENTO
CREATE OR REPLACE PROCEDURE SP_LISTAR_DIF_ENTRENAMIENTO (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM TrainingDifficulty
        ORDER BY name;
END SP_LISTAR_DIF_ENTRENAMIENTO;
/

-- SP_LISTAR_ENFERMEDADES
CREATE OR REPLACE PROCEDURE SP_LISTAR_ENFERMEDADES (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name FROM Disease ORDER BY name;
END SP_LISTAR_ENFERMEDADES;
/

-- SP_LISTAR_TRATAMIENTOS
CREATE OR REPLACE PROCEDURE SP_LISTAR_TRATAMIENTOS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name FROM Treatment ORDER BY name;
END SP_LISTAR_TRATAMIENTOS;
/


-- SP_LISTAR_MEDICAMENTOS
CREATE OR REPLACE PROCEDURE SP_LISTAR_MEDICAMENTOS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name FROM Medication ORDER BY name;
END SP_LISTAR_MEDICAMENTOS;
/

-- SP_LISTAR_CANTONES
CREATE OR REPLACE PROCEDURE SP_LISTAR_CANTONES (
    p_idProvince IN VARCHAR2,
    p_cursor     OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM Canton
        WHERE (p_idProvince IS NULL OR idProvince = TO_NUMBER(p_idProvince))
        ORDER BY name;
END SP_LISTAR_CANTONES;
/

-- SP_LISTAR_DISTRITOS
CREATE OR REPLACE PROCEDURE SP_LISTAR_DISTRITOS_CANTON (
    p_idCanton IN VARCHAR2,
    p_cursor   OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM District
        WHERE (p_idCanton IS NULL OR idCanton = TO_NUMBER(p_idCanton))
        ORDER BY name;
END SP_LISTAR_DISTRITOS_CANTON;
/
-- SP_LISTAR_DISTRITOS
CREATE OR REPLACE PROCEDURE SP_LISTAR_DISTRITOS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM District
        ORDER BY name;
END SP_LISTAR_DISTRITOS;
/

-- SP_LISTAR_PROVINCIAS
CREATE OR REPLACE PROCEDURE SP_LISTAR_PROVINCIAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM Province
        ORDER BY name;
END SP_LISTAR_PROVINCIAS;
/

-- SP_REGISTRAR_ENFERMEDAD_MASCOTA
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_ENFERMEDAD_MASCOTA (
    p_idPet     IN VARCHAR2,
    p_idDisease IN VARCHAR2,
    p_startDate IN DATE,
    p_createdBy IN VARCHAR2
) AS
BEGIN
    INSERT INTO petXDisease (
        idDisease, idPet, startDate
    ) VALUES (
        TO_NUMBER(p_idDisease),
        TO_NUMBER(p_idPet),
        p_startDate
    );
    COMMIT;
END SP_REGISTRAR_ENFERMEDAD_MASCOTA;
/

-- SP_REGISTRAR_TRATAMIENTO_MASCOTA
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_TRATAMIENTO_MASCOTA (
    p_idPet       IN VARCHAR2,
    p_idTreatment IN VARCHAR2,
    p_startDate   IN DATE,
    p_createdBy   IN VARCHAR2
) AS
BEGIN
    INSERT INTO PetTreatment (
        id, idPet, idTreatment, startDate,
        createdBy, createdAt
    ) VALUES (
        SEQ_PETTREATMENT.NEXTVAL,
        TO_NUMBER(p_idPet),
        TO_NUMBER(p_idTreatment),
        p_startDate,
        p_createdBy,
        CURRENT_TIMESTAMP
    );
    COMMIT;
END SP_REGISTRAR_TRATAMIENTO_MASCOTA;
/

CREATE OR REPLACE PROCEDURE SP_REGISTRAR_MEDICAMENTO_MASCOTA (
    p_idPet        IN VARCHAR2,
    p_idMedication IN VARCHAR2,
    p_dose         IN VARCHAR2,
    p_startDate    IN DATE,
    p_createdBy    IN VARCHAR2
) AS
BEGIN
    INSERT INTO PetMedication (
        id, idPet, idMedication, dose, startDate,
        createdBy, createdAt
    ) VALUES (
        SEQ_PETMEDICATION.NEXTVAL,
        TO_NUMBER(p_idPet),
        TO_NUMBER(p_idMedication),
        p_dose,
        p_startDate,
        p_createdBy,
        CURRENT_TIMESTAMP
    );
    COMMIT;
END SP_REGISTRAR_MEDICAMENTO_MASCOTA;
/
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_MASCOTA (
    p_name                        IN VARCHAR2,
    p_idBreed                     IN VARCHAR2,
    p_chip                        IN VARCHAR2,  
    p_idColour                    IN VARCHAR2,
    p_idState                     IN VARCHAR2,
    p_idSeverity                  IN VARCHAR2,
    p_idEnergyLevel               IN VARCHAR2,
    p_idDistrict                  IN VARCHAR2,
    p_petSize                     IN VARCHAR2,
    p_requiresMuchSpace           IN NUMBER,
    p_telephone                   IN VARCHAR2,
    p_email                       IN VARCHAR2,
    p_abandonSituationDescription IN VARCHAR2,
    p_descriptionNotes            IN VARCHAR2,
    p_idTrainingDifficulty        IN VARCHAR2,
    p_lossDate                    IN DATE,
    p_foundDate                   IN DATE,
    p_idVeterinarian              IN VARCHAR2,
    p_idCribHouse                 IN VARCHAR2,
    p_idRescuer                   IN VARCHAR2,
    p_idAssociation               IN VARCHAR2,
    p_beforePicture               IN BLOB,
    p_afterPicture                IN BLOB,
    p_createdBy                   IN VARCHAR2,
    p_id_generado                 OUT NUMBER
) AS
    v_id NUMBER;
BEGIN
    INSERT INTO Pet (
        id, name, idBreed, idColour,
        idState, idSeverity, idEnergyLevel, idDistrict,
        pet_size, requiresMuchSpace, telephone, email,
        abandonSituationDescription, descriptionNotes,
        idTrainingDifficulty, loss_date, foundDate,
        idVeterinarian, idCribHouse, idRescuer, idAssociation,
        beforePicture, afterPicture,
        createdBy, createdAt, modifiedBy, modifiedAt
    ) VALUES (
        SEQ_PET.NEXTVAL,
        p_name,
        TO_NUMBER(p_idBreed),
        TO_NUMBER(p_idColour),
        TO_NUMBER(p_idState),
        TO_NUMBER(p_idSeverity),
        TO_NUMBER(p_idEnergyLevel),
        TO_NUMBER(p_idDistrict),
        p_petSize,
        p_requiresMuchSpace,
        p_telephone,
        p_email,
        p_abandonSituationDescription,
        p_descriptionNotes,
        TO_NUMBER(p_idTrainingDifficulty),
        p_lossDate,
        p_foundDate,
        TO_NUMBER(p_idVeterinarian),
        TO_NUMBER(p_idCribHouse),
        TO_NUMBER(p_idRescuer),
        TO_NUMBER(p_idAssociation),
        p_beforePicture,
        p_afterPicture,
        p_createdBy, CURRENT_TIMESTAMP,
        p_createdBy, CURRENT_TIMESTAMP
    ) RETURNING id INTO v_id;

    IF p_chip IS NOT NULL THEN
    INSERT INTO Chip (id, petID, chipNumber, createdBy, createdAt, modifiedBy, modifiedAt)
    VALUES (SEQ_CHIP.NEXTVAL, v_id, TO_NUMBER(p_chip), p_createdBy, CURRENT_TIMESTAMP, p_createdBy, CURRENT_TIMESTAMP);
    END IF;

    p_id_generado := v_id;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        p_id_generado := -1;
        RAISE;
END SP_REGISTRAR_MASCOTA;
/
--SP_LISTAR_MASCOTAS
CREATE OR REPLACE PROCEDURE SP_LISTAR_MASCOTAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name FROM Pet ORDER BY name;
END;
/

