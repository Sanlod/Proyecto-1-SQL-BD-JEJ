--Niveles de energia
INSERT INTO EnergyLevel (id, name, createdBy, createdAt, modifiedBy, modifiedAt) 
VALUES (SEQ_ENERGYLEVEL.NEXTVAL, 'Muy Alto', USER, CURRENT_TIMESTAMP, USER, CURRENT_TIMESTAMP);

INSERT INTO EnergyLevel (id, name, createdBy, createdAt, modifiedBy, modifiedAt) 
VALUES (SEQ_ENERGYLEVEL.NEXTVAL, 'Alto', USER, CURRENT_TIMESTAMP, USER, CURRENT_TIMESTAMP);

INSERT INTO EnergyLevel (id, name, createdBy, createdAt, modifiedBy, modifiedAt) 
VALUES (SEQ_ENERGYLEVEL.NEXTVAL, 'Medio', USER, CURRENT_TIMESTAMP, USER, CURRENT_TIMESTAMP);

INSERT INTO EnergyLevel (id, name, createdBy, createdAt, modifiedBy, modifiedAt) 
VALUES (SEQ_ENERGYLEVEL.NEXTVAL, 'Bajo', USER, CURRENT_TIMESTAMP, USER, CURRENT_TIMESTAMP);

INSERT INTO EnergyLevel (id, name, createdBy, createdAt, modifiedBy, modifiedAt) 
VALUES (SEQ_ENERGYLEVEL.NEXTVAL, 'Muy Bajo', USER, CURRENT_TIMESTAMP, USER, CURRENT_TIMESTAMP);

COMMIT;