ALTER TABLE cribHouse
    ADD idPersona NUMBER NOT NULL;
    
ALTER TABLE cribHouse
    RENAME COLUMN idPersona TO idPerson; --Desliz    
    
ALTER TABLE cribHouse 
    ADD CONSTRAINT fkPersonCrib FOREIGN KEY (idPerson) REFERENCES person (id);
    
ALTER TABLE cribHouse
    ADD acceptedEnergyLevel VARCHAR2(50) NOT NULL;
    
ALTER TABLE CRIBHOUSE ADD (
    CREATEDBY             VARCHAR2(50 BYTE) NOT NULL,
    CREATEDAT             TIMESTAMP(6)      DEFAULT CURRENT_TIMESTAMP NOT NULL,
    MODIFIEDBY            VARCHAR2(50 BYTE) NOT NULL,
    MODIFIEDAT            TIMESTAMP(6)      DEFAULT CURRENT_TIMESTAMP NOT NULL
);