CREATE OR REPLACE NONEDITIONABLE PROCEDURE SP_REGISTRAR_CASACUNA (
    cc_requires IN NUMBER,
    cc_acceptedType IN VARCHAR2,
    cc_acceptedSize IN VARCHAR2,
    cc_district IN NUMBER,
    cc_idPerson IN NUMBER,
    cc_acceptedEnergy IN VARCHAR2,
    cc_id_generado OUT NUMBER
) AS
    v_new_id NUMBER;
BEGIN 
    v_new_id := seq_cribHouse.NEXTVAL;

    INSERT INTO cribHouse (
        id, 
        requiresFoodDonations,
        acceptedPetType, 
        acceptedPetSize,
        idDistrict, 
        idPerson,
        acceptedEnergyLevel,
        createdBy, 
        createdAt, 
        modifiedBy,
        modifiedAt 
    ) VALUES (
        v_new_id,
        cc_requires,
        cc_acceptedType,
        cc_acceptedSize,
        cc_district,
        cc_idPerson,
        cc_acceptedEnergy,
        'SYSTEM',
        CURRENT_TIMESTAMP,
        'SYSTEM',
        CURRENT_TIMESTAMP
    );

    cc_id_generado := v_new_id;
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        cc_id_generado := -1;
END;