CREATE OR REPLACE PROCEDURE SP_REGISTRAR_ENF_MASCOTA (
    p_idPet     IN VARCHAR2,
    p_idDisease IN VARCHAR2,
    p_startDate IN DATE,
    p_createdBy IN VARCHAR2
) AS
BEGIN
    INSERT INTO petXDisease (
        idDisease, idPet, startDate
    ) VALUES (
        TO_NUMBER(p_idDisease),
        TO_NUMBER(p_idPet),
        p_startDate
    );
    COMMIT;
END SP_REGISTRAR_ENF_MASCOTA;
/