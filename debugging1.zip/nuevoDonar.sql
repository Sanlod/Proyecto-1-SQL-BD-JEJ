CREATE OR REPLACE PROCEDURE SP_DONAR (
    p_amount IN NUMBER,
    p_PERCENTAGEXASSOCIATION IN NUMBER,
    p_IDPerson in NUMBER,
    p_idAssociation in NUMBER,
    p_idCurrency IN NUMBER,
    p_PersonName IN VARCHAR2
    ) 
    
AS

BEGIN
    INSERT INTO Donation (id, donation_date, amount, percentageXassociation, idPerson, idCurrency, createdBy, createdAt, modifiedBy, modifiedAt)
    VALUES (seqDonation.nextVal, sysdate, p_amount, p_PERCENTAGEXASSOCIATION, p_idPerson, p_idCurrency, p_PersonName, sysdate, p_PersonName, sysdate);
    
    INSERT INTO AssociationXDonation (idAssociation, idDonation)
    VALUES (p_idAssociation,seqDonation.currVal);
    
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN ROLLBACK;
    RAISE_APPLICATION_ERROR(-20001, 'Error al registrar la donación: ' || SQLERRM);
END SP_DONAR;
