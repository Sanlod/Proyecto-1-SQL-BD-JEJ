CREATE OR REPLACE PROCEDURE SP_STATS_MATCHES (
    p_start_date IN DATE,
    p_end_date IN DATE,
    p_idpettype IN NUMBER,
    p_cursor OUT SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            ms.name  AS match_status,
            COUNT(m.id) AS total,
            ROUND(AVG(m.similarityPercentage), 1) AS avg_similarity
        FROM Match m
        JOIN MatchStatus ms  ON ms.id  = m.idMatchStatus
        JOIN Pet pl  ON pl.id  = m.lostPetId
        JOIN Breed bl  ON bl.id  = pl.idBreed
        JOIN Pet pf  ON pf.id  = m.foundPetId
        JOIN Breed bf  ON bf.id  = pf.idBreed
        WHERE (p_start_date IS NULL OR TRUNC(m.matchDate) >= TRUNC(p_start_date))
          AND (p_end_date IS NULL OR TRUNC(m.matchDate) <= TRUNC(p_end_date))
          AND (p_idpettype  = 0
               OR (bl.idPetType = p_idpettype AND bf.idPetType = p_idpettype))
        GROUP BY ms.id, ms.name
        ORDER BY ms.name;
END SP_STATS_MATCHES;
/