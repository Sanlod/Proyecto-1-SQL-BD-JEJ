CREATE OR REPLACE PROCEDURE SP_CONSULTAR_SALUD(
    pNombre IN VARCHAR2,
    pChip IN VARCHAR2,
    pIdMedicina IN NUMBER,
    pIdTratamiento IN NUMBER,
    pIdEnfermedad IN NUMBER,
    pFechaInicio IN DATE,
    pFechaFin IN DATE,
    pCursor OUT SYS_REFCURSOR,
    pTotal OUT NUMBER)
AS
BEGIN
    SELECT COUNT(DISTINCT p.id)
    INTO pTotal
    FROM Pet p
    LEFT JOIN Chip          ch  ON ch.petId      = p.id
    LEFT JOIN PetMedication ptM ON ptM.idPet     = p.id
    LEFT JOIN PetTreatment  ptT ON ptT.idPet     = p.id
    LEFT JOIN PetXDisease   ptD ON ptD.idPet     = p.id
    WHERE (pNombre IS NULL OR UPPER(p.name)        LIKE '%' || UPPER(pNombre) || '%')
      AND (pChip IS NULL OR UPPER(ch.chipNumber) LIKE '%' || UPPER(pChip)   || '%')
      AND (pIdMedicina IS NULL OR ptM.idMedication     = pIdMedicina)
      AND (pIdTratamiento IS NULL OR ptT.idTreatment      = pIdTratamiento)
      AND (pIdEnfermedad IS NULL OR ptD.idDisease        = pIdEnfermedad)
      AND (pFechaInicio IS NULL OR TRUNC(ptM.startDate) >= TRUNC(pFechaInicio))
      AND (pFechaFin IS NULL OR TRUNC(ptM.startDate) <= TRUNC(pFechaFin));

    OPEN pCursor FOR
        WITH base AS (
            SELECT DISTINCT p.id, p.name AS nombre, ch.chipNumber AS chip
            FROM Pet p
            LEFT JOIN Chip ch  ON ch.petId      = p.id
            LEFT JOIN PetMedication ptM ON ptM.idPet     = p.id
            LEFT JOIN PetTreatment  ptT ON ptT.idPet     = p.id
            LEFT JOIN PetXDisease ptD ON ptD.idPet     = p.id
            WHERE (pNombre  IS NULL OR UPPER(p.name)        LIKE '%' || UPPER(pNombre) || '%')
              AND (pChip IS NULL OR UPPER(ch.chipNumber) LIKE '%' || UPPER(pChip)   || '%')
              AND (pIdMedicina IS NULL OR ptM.idMedication     = pIdMedicina)
              AND (pIdTratamiento IS NULL OR ptT.idTreatment      = pIdTratamiento)
              AND (pIdEnfermedad IS NULL OR ptD.idDisease        = pIdEnfermedad)
              AND (pFechaInicio IS NULL OR TRUNC(ptM.startDate) >= TRUNC(pFechaInicio))
              AND (pFechaFin IS NULL OR TRUNC(ptM.startDate) <= TRUNC(pFechaFin))
        ),
        meds AS (
            SELECT ptM.idPet,
                LISTAGG(med.name || ' (' || ptM.dose || ')', ', ') 
                    WITHIN GROUP (ORDER BY med.name) AS medicinas
            FROM (SELECT DISTINCT idPet, idMedication, dose FROM PetMedication) ptM
            JOIN Medication med ON med.id = ptM.idMedication
            GROUP BY ptM.idPet
        ),
        treats AS (
            SELECT ptT.idPet,
                   LISTAGG(treatm.name, ', ') WITHIN GROUP (ORDER BY treatm.name) AS tratamientos
            FROM (SELECT DISTINCT idPet, idTreatment FROM PetTreatment) ptT
            JOIN Treatment treatm ON treatm.id = ptT.idTreatment
            GROUP BY ptT.idPet
        ),
        diseases AS (
            SELECT ptD.idPet,
                   LISTAGG(dis.name, ', ') WITHIN GROUP (ORDER BY dis.name) AS enfermedades
            FROM (SELECT DISTINCT idPet, idDisease FROM PetXDisease) ptD
            JOIN Disease dis ON dis.id = ptD.idDisease
            GROUP BY ptD.idPet
        )
        SELECT
            b.id,
            b.nombre,
            b.chip,
            m.medicinas,
            t.tratamientos,
            d.enfermedades
        FROM base b
        LEFT JOIN meds m ON m.idPet = b.id
        LEFT JOIN treats t ON t.idPet = b.id
        LEFT JOIN diseases d ON d.idPet = b.id
        ORDER BY b.id DESC;
END SP_CONSULTAR_SALUD;
/