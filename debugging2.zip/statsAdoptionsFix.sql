CREATE OR REPLACE PROCEDURE SP_STATS_ADOPTIONS (
    p_start_date  IN DATE,
    p_end_date    IN DATE,
    p_idpettype   IN NUMBER,
    p_idbreed     IN NUMBER,
    p_cursor      OUT SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            'Exitosa' AS adoption_status,
            COUNT(DISTINCT p.id) AS total
        FROM Pet p
        JOIN Breed b  ON b.id = p.idbreed
        JOIN PetType pt ON pt.id = b.idpettype
        JOIN Adoption a  ON a.idPet = p.id
        JOIN AdoptionRequest ar ON ar.idAdoption = a.id
        JOIN Status s  ON s.id = ar.idStatus
        WHERE s.name = 'APROBADA'
          AND TRUNC(a.adoptionDate) BETWEEN TRUNC(p_start_date) AND TRUNC(p_end_date)
          AND pt.id = NVL(p_idpettype,pt.id)
          AND b.id = NVL(p_idbreed, b.id)
        GROUP BY 'Exitosa'

        UNION ALL

        SELECT
            'En espera'          AS adoption_status,
            COUNT(DISTINCT p.id) AS total
        FROM Pet p
        JOIN Breed   b  ON b.id  = p.idbreed
        JOIN PetType pt ON pt.id = b.idpettype
        JOIN Adoption a ON a.idPet = p.id
        JOIN AdoptionRequest ar ON ar.idAdoption = a.id
        JOIN Status s ON s.id = ar.idStatus
        WHERE s.name  = 'PENDIENTE'
          AND TRUNC(a.adoptiondate) BETWEEN TRUNC (p_start_date) AND TRUNC(p_end_date)
          AND pt.id = NVL(p_idpettype, pt.id)
          AND b.id     = NVL(p_idbreed,b.id)
        GROUP BY 'En espera';
END SP_STATS_ADOPTIONS;
/