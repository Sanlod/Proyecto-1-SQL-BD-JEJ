CREATE OR REPLACE PROCEDURE SP_CONSULTAR_SIN_ADOPTAR(
    meses IN NUMBER,
    tipoMascota IN NUMBER,
    raza IN NUMBER,
    color IN NUMBER,
    p_cursor OUT SYS_REFCURSOR,
    p_total OUT NUMBER,
    pEdad IN NUMBER
) AS

BEGIN
    SELECT COUNT(DISTINCT p.id) INTO p_total
    FROM Pet p
    LEFT JOIN Breed b ON b.id     = p.idBreed
    LEFT JOIN PetType pt ON pt.id    = b.idPetType
    LEFT JOIN Colour c ON c.id     = p.idColour
    WHERE (pt.id = NVL(tipoMascota, pt.id))
      AND (b.id = NVL(raza, b.id))
      AND (c.id = NVL(color, c.id))
      AND (p.idState = 3) ---Estado En adopción
      AND (ADD_MONTHS(p.loss_Date, meses) <= SYSDATE)
      AND (pEdad IS NULL OR
                   (pEdad = 1  AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) BETWEEN 0  AND 1)  OR
                   (pEdad = 5  AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) BETWEEN 1  AND 5)  OR
                   (pEdad = 9  AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) BETWEEN 5  AND 9)  OR
                   (pEdad = 12 AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) BETWEEN 10 AND 12) OR
                   (pEdad = 99 AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) > 12));
      
OPEN p_cursor
    FOR SELECT 
    p.id,
    p.name,
    pt.name AS Tipo,
    b.name AS Raza,
    c.name AS Color,
    TRUNC(MONTHS_BETWEEN(SYSDATE, p.BirthDate)) AS Edad,
    p.beforePicture,
    p.afterPicture
    FROM Pet p
    LEFT JOIN Breed b ON b.id = p.idBreed
    LEFT JOIN PetType pt ON pt.id = b.idPetType
    LEFT JOIN Colour c ON c.id     = p.idColour
    WHERE (pt.id = NVL(tipoMascota, pt.id))
      AND (b.id = NVL(raza, b.id))
      AND (c.id = NVL(color, c.id))
      AND (p.idState = 3) ---Estado En adopción
      AND (ADD_MONTHS(p.loss_date, meses) <= SYSDATE)
      AND (pEdad IS NULL OR
                   (pEdad = 1  AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) BETWEEN 0  AND 1)  OR
                   (pEdad = 5  AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) BETWEEN 1  AND 5)  OR
                   (pEdad = 9  AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) BETWEEN 5  AND 9)  OR
                   (pEdad = 12 AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) BETWEEN 10 AND 12) OR
                   (pEdad = 99 AND FLOOR(MONTHS_BETWEEN(SYSDATE, p.BirthDate) / 12) > 12))
      ORDER BY p.id DESC;
END SP_CONSULTAR_SIN_ADOPTAR;