CREATE OR REPLACE PROCEDURE SP_Quitar_Enfermedad(
    p_id_pet IN NUMBER,
    p_id_disease IN NUMBER
    )AS 
    BEGIN
        DELETE FROM PETXDISEASE
        WHERE PETXDISEASE.idPet = p_id_pet
        AND PETXDISEASE.idDisease = p_id_disease;
END SP_Quitar_Enfermedad;
/

CREATE OR REPLACE PROCEDURE SP_Quitar_Tratamiento(
    p_id_pet IN NUMBER,
    p_id_treatment IN NUMBER
    )AS 
    BEGIN
        DELETE FROM PETTREATMENT
        WHERE PETTREATMENT.idPet = p_id_pet
        AND PETTREATMENT.idTreatment = p_id_treatment;
END SP_Quitar_Tratamiento;
/

CREATE OR REPLACE PROCEDURE SP_Quitar_Medicina(
    p_id_pet IN NUMBER,
    p_id_medication IN NUMBER
    )AS 
    BEGIN
        DELETE FROM PETMEDICATION
        WHERE PETMEDICATION.idPet = p_id_pet
        AND PETMEDICATION.idMedication = p_id_medication;
END SP_Quitar_Medicina;
/

CREATE OR REPLACE PROCEDURE SP_CONSULTAR_TRATAMIENTOS(
    p_id_pet IN NUMBER,
    p_cursor OUT SYS_REFCURSOR
    )AS
    BEGIN
        OPEN p_cursor FOR
        SELECT t.id, t.name
        FROM Pet p
        JOIN PETTREATMENT pt ON p.id = pt.idPet
        JOIN TREATMENT t ON pt.idTreatment = t.id
        WHERE p_id_pet = p.id;
END SP_CONSULTAR_TRATAMIENTOS;
/        
        