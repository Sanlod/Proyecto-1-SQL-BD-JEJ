create or replace PROCEDURE SP_GESTIONAR_SOLICITUD (
    p_idSolicitud IN  NUMBER,
    p_idPet       IN  NUMBER,
    p_idPerson    IN  NUMBER,
    p_photo       IN  BLOB,
    p_notas       IN  VARCHAR2,
    p_nuevoEstado IN  NUMBER,
    p_usuario     IN  VARCHAR2,
    p_photo_new   IN  BLOB,
    p_resultado   OUT NUMBER
) AS
    v_idEstadoAprobado NUMBER;
    v_idEstadoRechazado NUMBER;
    v_idAdoption       NUMBER;
    v_idEstadoAdoptado NUMBER;
    v_idEstadoEnAdopcion NUMBER;
BEGIN
    SELECT id INTO v_idEstadoAprobado FROM Status WHERE UPPER(name) = 'APROBADA' AND ROWNUM = 1;
    SELECT id INTO v_idEstadoRechazado FROM Status WHERE UPPER(name) = 'RECHAZADA' AND ROWNUM = 1;
    SELECT id INTO v_idEstadoAdoptado FROM State WHERE UPPER(name) = 'ADOPTADO' AND ROWNUM = 1;
    SELECT id INTO v_idEstadoEnAdopcion FROM State WHERE UPPER(name) = 'EN ADOPCION' AND ROWNUM = 1;

    UPDATE AdoptionRequest
    SET IDSTATUS   = p_nuevoEstado,
        MODIFIEDBY = p_usuario,
        MODIFIEDAT = CURRENT_TIMESTAMP
    WHERE ID = p_idSolicitud;

    IF SQL%ROWCOUNT = 0 THEN
        p_resultado := 1;  
        RETURN;
    END IF;

    IF p_nuevoEstado = v_idEstadoAprobado THEN
        INSERT INTO Adoption (
            ID, IDPET, IDPERSON, NOTES, PHOTO, PHOTONEW, ADOPTIONDATE,
            CREATEDBY, CREATEDAT, MODIFIEDBY, MODIFIEDAT
        ) VALUES (
            SEQ_ADOPTION.NEXTVAL,
            p_idPet,
            p_idPerson,
            p_notas,
            p_photo,
            p_photo_new,
            CURRENT_TIMESTAMP,
            p_usuario, CURRENT_TIMESTAMP,
            p_usuario, CURRENT_TIMESTAMP
        ) RETURNING ID INTO v_idAdoption;

        UPDATE AdoptionRequest
        SET IDADOPTION = v_idAdoption
        WHERE ID = p_idSolicitud;

        UPDATE Pet
        SET IDSTATE = v_idEstadoAdoptado,
            MODIFIEDBY = p_usuario,
            MODIFIEDAT = CURRENT_TIMESTAMP
        WHERE ID = p_idPet;

    ELSIF p_nuevoEstado = v_idEstadoRechazado THEN
        UPDATE Pet
        SET IDSTATE = v_idEstadoEnAdopcion,
            MODIFIEDBY = p_usuario,
            MODIFIEDAT = CURRENT_TIMESTAMP
        WHERE ID = p_idPet;
    END IF;

    p_resultado := 0;
    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ROLLBACK;
        p_resultado := 2;  
    WHEN OTHERS THEN
        ROLLBACK;
        p_resultado := 1;
        RAISE;
END SP_GESTIONAR_SOLICITUD;
/