--COMO ADM
GRANT INSERT ON ADM.LOG TO PR;

GRANT SELECT ON ADM.S_LOG TO PR;

GRANT SELECT, INSERT, DELETE ON ADM.SESSION_USER_INFO TO PR;

CREATE TABLE ADM.SESSION_USER_INFO (
    ID_PERSON   NUMBER,
    FULL_NAME   VARCHAR2(200)
);


GRANT SELECT, INSERT, DELETE ON ADM.SESSION_USER_INFO TO PR;


--COMO PR
CREATE OR REPLACE PROCEDURE SP_SET_SESSION_USER (
    p_id_person IN NUMBER,
    p_full_name IN VARCHAR2
) AS
BEGIN
    DELETE FROM ADM.SESSION_USER_INFO;
    INSERT INTO ADM.SESSION_USER_INFO (ID_PERSON, FULL_NAME)
    VALUES (p_id_person, p_full_name);
END SP_SET_SESSION_USER;
/


-- Donation: amount y percentageXAssociation
CREATE OR REPLACE TRIGGER TRG_AUDIT_DONATION
AFTER INSERT OR UPDATE OR DELETE ON PR.Donation
FOR EACH ROW
DECLARE
    v_accion VARCHAR2(10);
    v_idPerson NUMBER;
    v_fullName VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;

    v_accion := CASE WHEN INSERTING THEN 'INSERT'
                     WHEN UPDATING  THEN 'UPDATE'
                     ELSE 'DELETE' END;

    BEGIN
        IF UPDATING('AMOUNT') OR INSERTING OR DELETING THEN
            INSERT INTO ADM.LOG (ID, SCHEMENAME, TABLENAME, FIELDNAME,
                PREVIOUSVALUE, CURRENTVALUE, CREATED_BY, CREATION_DATE,
                UPDATED_BY, UPDATED_DATE, ID_PERSON, CHANGE_DATE)
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'Donation', 'amount',
                TO_CHAR(:OLD.amount), TO_CHAR(:NEW.amount),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP);
        END IF;

        IF UPDATING('PERCENTAGEXASSOCIATION') OR INSERTING OR DELETING THEN
            INSERT INTO ADM.LOG (ID, SCHEMENAME, TABLENAME, FIELDNAME,
                PREVIOUSVALUE, CURRENTVALUE, CREATED_BY, CREATION_DATE,
                UPDATED_BY, UPDATED_DATE, ID_PERSON, CHANGE_DATE)
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'Donation', 'percentageXAssociation',
                TO_CHAR(:OLD.percentageXassociation), TO_CHAR(:NEW.percentageXassociation),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP);
        END IF;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
END TRG_AUDIT_DONATION;
/

-- CribHouse: requiresFoodDonations
CREATE OR REPLACE TRIGGER TRG_AUDIT_CRIBHOUSE
AFTER INSERT OR UPDATE OR DELETE ON PR.CribHouse
FOR EACH ROW
DECLARE
    v_accion    VARCHAR2(10);
    v_idPerson  NUMBER;
    v_fullName  VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;

    v_accion := CASE WHEN INSERTING THEN 'INSERT'
                     WHEN UPDATING  THEN 'UPDATE'
                     ELSE 'DELETE' END;

    BEGIN
        IF UPDATING('REQUIRESFOODDONATIONS') OR INSERTING OR DELETING THEN
            INSERT INTO ADM.LOG (ID, SCHEMENAME, TABLENAME, FIELDNAME,
                PREVIOUSVALUE, CURRENTVALUE, CREATED_BY, CREATION_DATE,
                UPDATED_BY, UPDATED_DATE, ID_PERSON, CHANGE_DATE)
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'CribHouse', 'requiresFoodDonations',
                TO_CHAR(:OLD.requiresFoodDonations), TO_CHAR(:NEW.requiresFoodDonations),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP);
        END IF;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
END TRG_AUDIT_CRIBHOUSE;
/

-- PetMedication: dosis
CREATE OR REPLACE TRIGGER TRG_AUDIT_PETMEDICATION
AFTER INSERT OR UPDATE OR DELETE ON PR.PetMedication
FOR EACH ROW
DECLARE
    v_idPerson  NUMBER;
    v_fullName  VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;

    BEGIN
        IF UPDATING('DOSE') OR INSERTING OR DELETING THEN
            INSERT INTO ADM.LOG (ID, SCHEMENAME, TABLENAME, FIELDNAME,
                PREVIOUSVALUE, CURRENTVALUE, CREATED_BY, CREATION_DATE,
                UPDATED_BY, UPDATED_DATE, ID_PERSON, CHANGE_DATE)
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'PetXDisease', 'dosis',
                TO_CHAR(:OLD.dose), TO_CHAR(:NEW.dose),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP);
        END IF;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
END TRG_AUDIT_PETMEDICATION;
/

-- Pet: idState
CREATE OR REPLACE TRIGGER TRG_AUDIT_PET
AFTER INSERT OR UPDATE OR DELETE ON PR.Pet
FOR EACH ROW
DECLARE
    v_idPerson  NUMBER;
    v_fullName  VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;

    BEGIN
        IF UPDATING('IDSTATE') OR INSERTING OR DELETING THEN
            INSERT INTO ADM.LOG (ID, SCHEMENAME, TABLENAME, FIELDNAME,
                PREVIOUSVALUE, CURRENTVALUE, CREATED_BY, CREATION_DATE,
                UPDATED_BY, UPDATED_DATE, ID_PERSON, CHANGE_DATE)
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'Pet', 'idState',
                TO_CHAR(:OLD.idState), TO_CHAR(:NEW.idState),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP);
        END IF;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
END TRG_AUDIT_PET;
/

-- AdoptionRequest: idStatus
CREATE OR REPLACE TRIGGER TRG_AUDIT_ADOPTIONREQUEST
AFTER INSERT OR UPDATE OR DELETE ON PR.AdoptionRequest
FOR EACH ROW
DECLARE
    v_idPerson  NUMBER;
    v_fullName  VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;

    BEGIN
        IF UPDATING('IDSTATUS') OR INSERTING OR DELETING THEN
            INSERT INTO ADM.LOG (ID, SCHEMENAME, TABLENAME, FIELDNAME,
                PREVIOUSVALUE, CURRENTVALUE, CREATED_BY, CREATION_DATE,
                UPDATED_BY, UPDATED_DATE, ID_PERSON, CHANGE_DATE)
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'AdoptionRequest', 'idStatus',
                TO_CHAR(:OLD.idStatus), TO_CHAR(:NEW.idStatus),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP);
        END IF;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
END TRG_AUDIT_ADOPTIONREQUEST;
/

-- Bounty: amount
CREATE OR REPLACE TRIGGER TRG_AUDIT_BOUNTY
AFTER INSERT OR UPDATE OR DELETE ON PR.Bounty
FOR EACH ROW
DECLARE
    v_idPerson  NUMBER;
    v_fullName  VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;

    BEGIN
        IF UPDATING('AMOUNT') OR INSERTING OR DELETING THEN
            INSERT INTO ADM.LOG (ID, SCHEMENAME, TABLENAME, FIELDNAME,
                PREVIOUSVALUE, CURRENTVALUE, CREATED_BY, CREATION_DATE,
                UPDATED_BY, UPDATED_DATE, ID_PERSON, CHANGE_DATE)
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'Bounty', 'amount',
                TO_CHAR(:OLD.amount), TO_CHAR(:NEW.amount),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP);
        END IF;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
END TRG_AUDIT_BOUNTY;
/