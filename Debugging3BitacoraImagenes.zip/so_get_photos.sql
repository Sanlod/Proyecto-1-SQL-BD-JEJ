create or replace PROCEDURE SP_GET_PHOTOS(
    p_idAdoption IN NUMBER,
    p_cursor OUT SYS_REFCURSOR
    ) AS
    BEGIN
    OPEN p_cursor FOR
    SELECT PHOTO, PHOTONEW FROM ADOPTION WHERE ADOPTION.id = p_idAdoption;
END SP_GET_PHOTOS;