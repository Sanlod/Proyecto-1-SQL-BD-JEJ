DROP TRIGGER TRG_AUDIT_BLACKLIST;

CREATE OR REPLACE TRIGGER TRG_AUDIT_BLACKLIST
AFTER INSERT OR UPDATE OF idBlackList OR DELETE ON PR.person
FOR EACH ROW
DECLARE
    v_idPerson NUMBER;
    v_fullName VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson:= NULL;
        v_fullName:= 'SYSTEM';
    END;

    BEGIN
        IF UPDATING ('idBlackList')   
        THEN
            INSERT INTO ADM.log (
                id, schemeName, tableName, fieldName,
                previousValue, currentValue, 
                created_by, creation_date,
                updated_by, updated_date, 
                id_person, change_date
            )
            VALUES (
                ADM.S_LOG.NEXTVAL, 'PR', 'Person', 'idBlacklist',
                TO_CHAR(:OLD.idBlackList), TO_CHAR(:NEW.idBlackList),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP
            );
        END IF;
        
        IF INSERTING
        THEN
            INSERT INTO ADM.log (
                id, schemeName, tableName, fieldName,
                previousValue, currentValue, 
                created_by, creation_date,
                updated_by, updated_date, 
                id_person, change_date
            )
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'Person', 'idBlacklist',
                TO_CHAR(:NEW.idBlackList), TO_CHAR(:NEW.idBlackList),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP
            );
            END IF;
    EXCEPTION WHEN OTHERS THEN 
        NULL; 
    END;
END TRG_AUDIT_BLACKLIST;
/


--Trigger UserType
CREATE OR REPLACE TRIGGER TRG_AUDIT_USER_TYPE
AFTER INSERT OR UPDATE OF idUserType OR DELETE ON PR.appUser
FOR EACH ROW
DECLARE
    v_idPerson NUMBER;
    v_fullName VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;
    BEGIN
        IF UPDATING ('idUserType') THEN
            INSERT INTO ADM.log (
                id, schemeName, tableName, fieldName,
                previousValue, currentValue, 
                created_by, creation_date,
                updated_by, updated_date, 
                id_person, change_date
            )
            VALUES (
                ADM.S_LOG.NEXTVAL, 'PR', 'appUser', 'idUserType',
                TO_CHAR(:OLD.idUserType), TO_CHAR(:NEW.idUserType),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP
            );
        END IF;
        
        IF INSERTING
        THEN
            INSERT INTO ADM.log (
                id, schemeName, tableName, fieldName,
                previousValue, currentValue, 
                created_by, creation_date,
                updated_by, updated_date, 
                id_person, change_date
            )
            VALUES (ADM.S_LOG.NEXTVAL, 'PR', 'Person', 'userType',
                TO_CHAR(:NEW.idUserType), TO_CHAR(:NEW.idUserType),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP
            );
            END IF;
    EXCEPTION WHEN OTHERS THEN 
        NULL; 
    END;
END TRG_AUDIT_USER_TYPE;
/


--Trigger idAssociaion 
CREATE OR REPLACE TRIGGER TRG_AUDIT_ASSOC
AFTER INSERT OR UPDATE OF idAssociation OR DELETE ON PR.associationXDonation
FOR EACH ROW
DECLARE
    v_idPerson NUMBER;
    v_fullName VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;
    
    BEGIN
        IF INSERTING OR DELETING OR UPDATING ('idAssociation') THEN
            INSERT INTO ADM.log (
                id, schemeName, tableName, fieldName,
                previousValue, currentValue, 
                created_by, creation_date,
                updated_by, updated_date, 
                id_person, change_date
            )
            VALUES (
                ADM.S_LOG.NEXTVAL, 'PR', 'associationXDonation', 'idAssociation',
                TO_CHAR(:OLD.idAssociation), TO_CHAR(:NEW.idAssociation),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP
            );   
        END IF;
    EXCEPTION WHEN OTHERS THEN 
        NULL; 
    END;
END TRG_AUDIT_ASSOC_DONATION;
/




--Trigger idDonation
CREATE OR REPLACE TRIGGER TRG_AUDIT_IDDONATION
AFTER INSERT OR UPDATE OF idDonation OR DELETE ON PR.associationXDonation
FOR EACH ROW
DECLARE
    v_idPerson NUMBER;
    v_fullName VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;
    
    BEGIN
        IF INSERTING OR DELETING OR UPDATING('idDonation') THEN
            INSERT INTO ADM.log (
                id, schemeName, tableName, fieldName,
                previousValue, currentValue, 
                created_by, creation_date,
                updated_by, updated_date, 
                id_person, change_date
            )
            VALUES (
                ADM.S_LOG.NEXTVAL, 'PR', 'associationXDonation', 'idDonation',
                TO_CHAR(:OLD.idAssociation), TO_CHAR(:NEW.idAssociation),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson, CURRENT_TIMESTAMP
            );   
        END IF;
    EXCEPTION WHEN OTHERS THEN 
        NULL; 
    END;
END TRG_AUDIT_DONATION;
/



--Trigger matchStatus
CREATE OR REPLACE TRIGGER TRG_AUDIT_MATCH_STATUS
AFTER INSERT OR UPDATE OF idMatchStatus OR DELETE ON PR.match
FOR EACH ROW
DECLARE
    v_idPerson NUMBER;
    v_fullName VARCHAR2(200);
BEGIN
    BEGIN
        SELECT ID_PERSON, FULL_NAME INTO v_idPerson, v_fullName
        FROM ADM.SESSION_USER_INFO WHERE ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
        v_idPerson := NULL;
        v_fullName := 'SYSTEM';
    END;

    BEGIN
        IF INSERTING OR DELETING OR UPDATING('idMatchStatus') THEN
            INSERT INTO ADM.log (
                id, schemeName, tableName, fieldName,
                previousValue, currentValue, 
                created_by, creation_date,
                updated_by, updated_date, 
                id_person, change_date
            )
            VALUES (
                ADM.S_LOG.NEXTVAL, 'PR', 'MATCH', 'IDMATCHSTATUS',
                TO_CHAR(:OLD.IDMATCHSTATUS), TO_CHAR(:NEW.IDMATCHSTATUS),
                v_fullName, CURRENT_TIMESTAMP,
                v_fullName, CURRENT_TIMESTAMP,
                v_idPerson,  CURRENT_TIMESTAMP
            ); 
        END IF;
    EXCEPTION WHEN OTHERS THEN 
        NULL; 
    END;
END TRG_AUDIT_MATCH_STATUS;
/
