--DESDE ADM

GRANT SELECT ON ADM.LOG TO PR;

--DESDE PR

CREATE OR REPLACE PROCEDURE SP_CONSULTAR_BITACORA(
    p_username IN VARCHAR2,
    p_tabla IN VARCHAR2,
    p_fecha IN DATE,
    p_cursor OUT SYS_REFCURSOR,
    p_total OUT NUMBER
    )AS 
    BEGIN
        SELECT COUNT(*) INTO p_total FROM ADM.LOG log
            WHERE (p_username IS NULL OR UPPER(log.updated_by)  = UPPER(p_username))
            AND (p_tabla IS NULL OR UPPER(log.tablename)   = UPPER(p_tabla))
            AND (p_fecha IS NULL OR TRUNC(log.updated_date) = TRUNC(p_fecha));
        
        OPEN p_cursor FOR
            SELECT * FROM ADM.LOG log
            WHERE (p_username IS NULL OR UPPER(log.updated_by)  = UPPER(p_username))
            AND (p_tabla IS NULL OR UPPER(log.tablename)   = UPPER(p_tabla))
            AND (p_fecha IS NULL OR TRUNC(log.updated_date) = TRUNC(p_fecha))
            ORDER BY log.updated_date DESC;
END SP_CONSULTAR_BITACORA;
/

CREATE OR REPLACE PROCEDURE SP_LISTAR_USUARIOS(
    p_cursor OUT SYS_REFCURSOR)AS
    BEGIN
        OPEN p_cursor FOR
        SELECT username FROM APPUSER;
END SP_LISTAR_USUARIOS;
/
        


