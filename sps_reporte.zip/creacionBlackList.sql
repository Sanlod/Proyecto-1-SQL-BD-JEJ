INSERT INTO BLACKLIST(id,createdby,createdat,modifiedby,modifiedat)
VALUES(1,'PR',SYSDATE,'PR',SYSDATE);