CREATE OR REPLACE PROCEDURE SP_CONSULTAR_PERSONAS (
    p_name          IN  VARCHAR2,
    p_first_surname IN  VARCHAR2,
    p_second_surname IN VARCHAR2,
    p_in_blacklist  IN  VARCHAR2,
    p_cursor          OUT SYS_REFCURSOR,
    p_total           OUT NUMBER
) AS
BEGIN
    SELECT COUNT(*) INTO p_total
    FROM Person p
    WHERE (p_name           IS NULL OR UPPER(p.firstName)    LIKE UPPER('%' || p_name || '%'))
      AND (p_first_surname  IS NULL OR UPPER(p.firstSurname) LIKE UPPER('%' || p_first_surname || '%'))
      AND (p_second_surname IS NULL OR UPPER(p.secondSurname) LIKE UPPER('%' || p_second_surname || '%'))
      AND (p_in_blacklist   IS NULL OR
           (p_in_blacklist = '1' AND p.idBlacklist IS NOT NULL) OR
           (p_in_blacklist = '0' AND p.idBlacklist IS NULL));

    OPEN p_cursor FOR
        SELECT
            p.id,
            p.firstName || ' ' ||
            NVL(p.secondName || ' ', '') ||
            p.firstSurname || ' ' ||
            NVL(p.secondSurname, '')  AS full_name,
            p.notes,
            p.rating,
            CASE WHEN p.idBlacklist IS NOT NULL THEN 'Sí' ELSE 'No' END AS in_blacklist
        FROM Person p
        WHERE (p_name           IS NULL OR UPPER(p.firstName)    LIKE UPPER('%' || p_name || '%'))
          AND (p_first_surname  IS NULL OR UPPER(p.firstSurname) LIKE UPPER('%' || p_first_surname || '%'))
          AND (p_second_surname IS NULL OR UPPER(p.secondSurname) LIKE UPPER('%' || p_second_surname || '%'))
          AND (p_in_blacklist   IS NULL OR
               (p_in_blacklist = '1' AND p.idBlacklist IS NOT NULL) OR
               (p_in_blacklist = '0' AND p.idBlacklist IS NULL))
        ORDER BY p.firstSurname, p.firstName;
END SP_CONSULTAR_PERSONAS;
/