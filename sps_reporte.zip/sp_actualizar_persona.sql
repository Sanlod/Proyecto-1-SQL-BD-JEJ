CREATE OR REPLACE PROCEDURE SP_ACTUALIZAR_PERSONA (
    p_id            IN NUMBER,
    p_firstName     IN VARCHAR2,
    p_secondName    IN VARCHAR2,
    p_firstSurname  IN VARCHAR2,
    p_secondSurname IN VARCHAR2,
    p_notes         IN VARCHAR2,
    p_rating        IN NUMBER,
    p_updatedBy     IN VARCHAR2,
    p_idBlackList   IN NUMBER
) AS
BEGIN
    UPDATE Person
    SET firstName = NVL(p_firstName, firstName),
        secondName = NVL(p_secondName, secondName),
        firstSurname = NVL(p_firstSurname, firstSurname),
        secondSurname = NVL(p_secondSurname, secondSurname),
        notes = NVL(p_notes, notes),
        rating = NVL(p_rating, rating),
        modifiedBy = p_updatedBy,
        idBlacklist = NVL(p_idBlackList, idBlacklist),
        modifiedAt = CURRENT_TIMESTAMP
    WHERE id = p_id;
    
    COMMIT;
END SP_ACTUALIZAR_PERSONA;
/