CREATE OR REPLACE PROCEDURE SP_STATS_DONATIONS_BY_ASSOCIATION (
    p_start_date IN DATE,
    p_end_date   IN DATE,
    p_cursor     OUT SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            a.name              AS entity_name,
            'Asociación'        AS entity_type,
            SUM(d.amount)       AS total
        FROM Donation d
        JOIN AssociationXDonation axd ON axd.idDonation   = d.id
        JOIN Association          a   ON a.id              = axd.idAssociation
        WHERE TRUNC(d.donation_date) BETWEEN TRUNC(p_start_date) AND TRUNC(p_end_date)
        GROUP BY a.name, 'Asociación' --Fijarse este group 
        ORDER BY total DESC;
END SP_STATS_DONATIONS_BY_ASSOCIATION;
/