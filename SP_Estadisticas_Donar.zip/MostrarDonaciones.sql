
CREATE OR REPLACE PROCEDURE SP_CONSULTAR_DONACIONES (
    p_fecha_desde     IN  TIMESTAMP,
    p_fecha_hasta     IN  TIMESTAMP,
    p_id_person       IN  NUMBER,
    p_id_association  IN  NUMBER,
    p_cursor          OUT SYS_REFCURSOR,
    p_total           OUT NUMBER
) AS
BEGIN
    SELECT COUNT(*)
    INTO p_total
    FROM donation d
    JOIN person p             ON p.id = d.idPerson
    JOIN associationXDonation axd ON axd.idDonation = d.id
    JOIN association a        ON a.id = axd.idAssociation
    WHERE (p_fecha_desde  IS NULL OR d.donation_date >= p_fecha_desde)
      AND (p_fecha_hasta  IS NULL OR d.donation_date <= p_fecha_hasta)
      AND (p_id_person    IS NULL OR d.idPerson       = p_id_person)
      AND (p_id_association IS NULL OR axd.idAssociation = p_id_association);

    OPEN p_cursor FOR
        SELECT
            d.id                                        AS id_donacion,
            d.donation_date                             AS fecha,
            d.amount                                    AS monto,
            d.percentageXAssociation                    AS porcentaje,
            p.firstName || ' ' ||
                NVL(p.secondName || ' ', '') ||
                p.firstSurname || ' ' ||
                NVL(p.secondSurname, '')                AS donador,
            a.name                                      AS asociacion
        FROM donation d
        JOIN person p             ON p.id = d.idPerson
        JOIN associationXDonation axd ON axd.idDonation = d.id
        JOIN association a        ON a.id = axd.idAssociation
        WHERE (p_fecha_desde  IS NULL OR d.donation_date >= p_fecha_desde)
          AND (p_fecha_hasta  IS NULL OR d.donation_date <= p_fecha_hasta)
          AND (p_id_person    IS NULL OR d.idPerson       = p_id_person)
          AND (p_id_association IS NULL OR axd.idAssociation = p_id_association)
        ORDER BY d.donation_date DESC;
END SP_CONSULTAR_DONACIONES;
/