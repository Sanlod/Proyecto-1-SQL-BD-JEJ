CREATE OR REPLACE PROCEDURE SP_STATS_BOUNTIES_BY_RESCUER (
    p_start_date IN DATE,
    p_end_date   IN DATE,
    p_cursor     OUT SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            per.firstName || ' ' || per.firstSurName AS entity_name,
            'Rescatista'                              AS entity_type,
            SUM(b.amount)                             AS total
        FROM Bounty  b
        JOIN Pet     p   ON p.id  = b.idPet
        JOIN Rescuer r   ON r.id  = p.idrescuer
        JOIN Person  per ON per.id = r.id
        WHERE TRUNC(p.createdat) BETWEEN TRUNC(p_start_date) AND TRUNC(p_end_date)
        GROUP BY per.firstName, per.firstSurName, 'Rescatista'
        ORDER BY total DESC;
END SP_STATS_BOUNTIES_BY_RESCUER;
/