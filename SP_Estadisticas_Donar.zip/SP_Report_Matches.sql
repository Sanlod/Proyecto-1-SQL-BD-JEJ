CREATE OR REPLACE PROCEDURE SP_STATS_MATCHES (
    p_cursor OUT SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            ms.name                               AS match_status,
            COUNT(m.id)                           AS total,
            ROUND(AVG(m.similarityPercentage), 1) AS avg_similarity
        FROM Match m
        JOIN MatchStatus ms ON ms.id = m.idMatchStatus
        GROUP BY ms.id, ms.name
        ORDER BY ms.name;
END SP_STATS_MATCHES;
/