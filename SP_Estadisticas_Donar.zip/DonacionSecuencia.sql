ALTER TABLE Donation
ADD idCurrency NUMBER;

ALTER TABLE Donation
ADD CONSTRAINT fk_donation_currency
FOREIGN KEY (idCurrency)
REFERENCES Currency(id);


CREATE SEQUENCE seqDonation
START WITH 1       
INCREMENT BY 1     
MINVALUE 1
MAXVALUE 999999
NOCYCLE            
CACHE 20;    