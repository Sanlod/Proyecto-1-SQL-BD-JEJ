CREATE OR REPLACE PROCEDURE SP_STATS_PETS_BY_TYPE_STATE (
    p_start_date IN DATE,
    p_end_date   IN DATE,
    p_cursor     OUT SYS_REFCURSOR
)
AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            pt.name     AS pet_type_name,
            s.name      AS state_name,
            COUNT(p.id) AS total
        FROM Pet p
        JOIN Breed   b  ON b.id  = p.idbreed
        JOIN PetType pt ON pt.id = b.idpettype
        JOIN State   s  ON s.id  = p.idstate
        WHERE (
            (p.loss_date IS NOT NULL AND TRUNC(p.loss_date) BETWEEN TRUNC(p_start_date) AND TRUNC(p_end_date))
            OR
            (p.founddate IS NOT NULL AND TRUNC(p.founddate) BETWEEN TRUNC(p_start_date) AND TRUNC(p_end_date))
            OR
            (p.loss_date IS NULL AND p.founddate IS NULL
             AND TRUNC(p.createdat) BETWEEN TRUNC(p_start_date) AND TRUNC(p_end_date))
        )
        GROUP BY pt.name, s.name
        ORDER BY pt.name, s.name;
END SP_STATS_PETS_BY_TYPE_STATE;
/