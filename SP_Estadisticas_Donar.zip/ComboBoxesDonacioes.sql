
CREATE OR REPLACE PROCEDURE SP_LISTAR_PERSONAS (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id,
               firstName || ' ' ||
               NVL(secondName || ' ', '') ||
               firstSurname || ' ' ||
               NVL(secondSurname, '') AS nombre_completo
        FROM person
        ORDER BY firstSurname, firstName;
END SP_LISTAR_PERSONAS;
/

CREATE OR REPLACE PROCEDURE SP_LISTAR_ASOCIACIONES (
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT id, name
        FROM association
        ORDER BY name;
END SP_LISTAR_ASOCIACIONES;
/